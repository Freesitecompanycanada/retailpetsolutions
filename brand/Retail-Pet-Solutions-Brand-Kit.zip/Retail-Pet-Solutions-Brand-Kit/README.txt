RETAIL PET SOLUTIONS · BRAND KIT
Version 1.0 · November 2026
Prepared for Campbell Woods by Free Site Company

WHAT'S INSIDE
01 Logos / SVG   Scalable vector logos. Best for printers, sign shops and web designers.
01 Logos / PNG   Transparent, high-resolution images for Word, Google Docs, Canva and social media.
02 Retail Pet Solutions Brand Guidelines.pdf   How to use the logo, colours and fonts.

WHICH LOGO TO USE
Horizontal_FullColour   Your go-to logo. Use it first.
Stacked_FullColour      Square spaces: signs, flyers, booth banners.
Mark_FullColour         The heart paw on its own: stickers, small spaces.
Reversed                For dark backgrounds and photos.
Moss / Black / White    One colour versions for single-ink printing, invoices and embroidery.
Social_ProfilePicture   Facebook, Instagram, LinkedIn and Google Business profile picture.
Favicon_AppIcon / favicon.ico   Browser tab icon for the website.

COLOURS
Moss    #3E5B45   RGB 62 91 69
Sand    #F4EDE3   RGB 244 237 227
Sage    #A8C3A0   RGB 168 195 160
Bark    #4A3A2E   RGB 74 58 46
Honey   #E9B949   RGB 233 185 73

FONT
Nunito (free): https://fonts.google.com/specimen/Nunito
Headlines Black 900 · Labels ExtraBold 800 · Body Regular 400

Questions? Free Site Company · freesitecompanycanada@gmail.com
